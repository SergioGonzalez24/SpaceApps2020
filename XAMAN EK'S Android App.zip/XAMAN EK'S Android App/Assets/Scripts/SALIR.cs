﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SALIR : MonoBehaviour
{
    public void SalirApp(){
        Application.Quit();
    }
}
